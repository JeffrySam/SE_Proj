﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Username] NCHAR(15) NOT NULL, 
    [Password] NCHAR(15) NOT NULL, 
    [Admin_Type] NCHAR(15) NOT NULL
)
